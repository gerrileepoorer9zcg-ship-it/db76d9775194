// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("minimal versions\n", stdout);
  return lionss_run_workload("minimal-versions");
}
