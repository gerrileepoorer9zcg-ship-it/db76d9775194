// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("quarantine flaky"); }
int main(){
  announce();
  return lionss_run_workload("quarantine-flaky");
}
