// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("lto build"); }
int main(){
  announce();
  return lionss_run_workload("lto-build");
}
